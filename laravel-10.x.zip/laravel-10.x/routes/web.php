<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\UsuariosController;
use App\Http\Controllers\AutoresController;
use App\Http\Controllers\LivrosController;
use App\Http\Controllers\EmprestimosController;
use App\Models\Livros;

Route::get('/', function () {
    return view('home');
});

/*Usuarios*/

Route::get('/usuarios', [UsuariosController::class, 'index']);
Route::get('/usuarios/cadastro', [UsuariosController::class, 'cadastro']);
Route::get('/usuarios/cadastro/{id}', [UsuariosController::class, 'cadastro']);
Route::post('/usuarios/salvar', [UsuariosController::class, 'salvar']);
Route::get('/usuarios/remover/{id}', [UsuariosController::class, 'remover']);


/*Autores*/

Route::get('/autores', [AutoresController::class, 'index']);
Route::get('/autores/cadastro', [AutoresController::class, 'cadastro']);
Route::get('/autores/cadastro/{id}', [AutoresController::class, 'autores']);
Route::post('/autores/salvar', [AutoresController::class, 'salvar']);
Route::get('/autores/remover/{id}', [AutoresController::class, 'remover']);


/*Livros*/

Route::get('/livros', [LivrosController::class,'index']);
Route::get('/livros/cadastro', [LivrosController::class, 'cadastro']);
Route::get('/livros/cadastro/{id}', [LivrosController::class, 'livros']);
Route::post('/livros/salvar', [LivrosController::class, 'salvar']);
Route::get('/livros/remover/{id}', [LivrosController::class, 'remover']);


/*Emprestimos*/

Route::get('/emprestimos', [EmprestimosController::class, 'index']);
Route::get('/emprestimos/cadastro', [EmprestimosController::class, 'cadastro']);
Route::get('/emprestimos/cadastro/{id}', [EmprestimosController::class, 'cadastro']);
Route::post('/emprestimos/salvar', [EmprestimosController::class, 'salvar']);
Route::get('/emprestimos/remover/{id}', [EmprestimosController::class, 'remover']);
