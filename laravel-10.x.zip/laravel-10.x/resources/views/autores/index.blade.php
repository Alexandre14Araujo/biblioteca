@extends('layouts.main')

@section('title', 'Biblioteca')

@section('h1', 'Listagem de Autores')

@section('content')

    <main class="py-5">
        <section class="py-5">
            <div class="container">
                <table class="table">
                    <tr class="col">
                        <th>Nome</th>
                        <th>Editar</th>
                        <th>Excluir</th>
                    </tr>
                    @foreach ($autores as $autores)
                    <tr>
                        <td>{{ $autores->nome }}</td>
                        <td><a href='/autores/cadastro/{{ $autores->id }}'>Editar</a></td>
                        <td><a href='/autores/remover/{{ $autores->id }}'>Remover</a></td>
                    </tr>
                    @endforeach
                </table>
            </div>
        </section>
    </main>

    <br><br>
    <div style="text-align: right">
        <a href="/autores/cadastro" class="btn btn-lg btn-primary">Cadastrar Autor</a>
    </div>

    @endsection
