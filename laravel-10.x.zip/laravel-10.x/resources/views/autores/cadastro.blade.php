@extends('layouts.main')

@section('title', 'Cadastrar Livro')

@section('h1', 'Cadastro de Livro')

@section('content')

    <main class="py-5">
        <section class="py-5">
            <div class="container">
                <form method="POST" action="/autores/salvar">
                    @csrf
                    <div class="form-row">
                        <div class="form-group">
                            <label for="nome" class="form-label">Nome</label>
                            <input type="text" name="nome" placeholder="Digite o seu Nome" class="form-control"
                                value="{{ @$resultado->nome }}"><br><br>
                        </div>
                        <div class="form-group">
                            <input type="hidden" name="id" value="{{ @$resultado->id }}">
                        </div>
                        <button type="submit" class="btn btn-primary">Salvar</button>
                    </div>
                </form>
            </div>
        </section>
    </main>
@endsection
