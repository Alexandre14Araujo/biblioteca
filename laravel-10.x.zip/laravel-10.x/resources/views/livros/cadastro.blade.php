@extends('layouts.main')

@section('title', 'Cadastrar Livro')

@section('h1', 'Cadastro de livro')

@section('content')

   <main class="py-5">
       <section class="py-5">
            <div class="container">
                    <form method="POST" action="/livros/salvar">
                        @csrf
                        <div class="form-row">
                            <div class="form-group">
                                <label for="titulo" class="form-label">Título </label>
                                <input type="text" name="titulo" placeholder="Digite o titulo" class="form-control" value="{{@$resultado->titulo}}"><br>
                            </div>
                            <div class="form-group">
                                <label for="autor">Autor</label> <br>
                                <select name="id_autor">
                                <option value="">Selecione um autor</option>
                                @foreach($autores as $autor)
                                <option value="{{$autor->id}}">{{$autor->nome}}</option>
                                @endforeach
                                </select>
                            </div> <br><br>

                            <div>

                                <input type="hidden" name="id" value="{{@$resultado->id}}">
                            </div>
                            <button type="submit" class="btn btn-primary">Salvar</button>
                        </div>
                    </form>
            </div>

       </section>
   </main>

@endsection
