@extends('layouts.main')

@section('title', 'Biblioteca')

@section('h1', 'Lista de livros')

@section('content')

<main class="py-5">
       <section class="py-5">
            <div class="container">
                <table class="table">
                <tr class="col">
                <th>Título</th>
                <th>Autor</th>
                <th>Editar</th>
                <th>Excluir</th>
                </tr>
                @foreach($livros as $livro)
                <tr>
                <td>{{ $livro->titulo }}</td>
                <td>{{ isset($livro->autor) ? $livro->autor->nome : 'Sem autor'}}</td>
                <td><a href='/livros/cadastro/{{ $livro->id }}'>Editar</a></td>
                <td><a href='/livros/remover/{{ $livro->id }}'>Remover</a></td>
                </tr>
                @endforeach
                </table>
            </div>
        </section>
</main>

                <br><br>
<div style="text-align: right;">

    <a href="/livros/cadastro" class="btn btn-lg btn-primary" >Cadastrar livro</a>
</div>




@endsection
