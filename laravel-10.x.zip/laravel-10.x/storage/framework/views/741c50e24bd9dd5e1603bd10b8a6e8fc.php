<?php $__env->startSection('title', 'Biblioteca'); ?>

<?php $__env->startSection('h1', 'Listagem de Autores'); ?>

<?php $__env->startSection('content'); ?>

    <main class="py-5">
        <section class="py-5">
            <div class="container">
                <table class="table">
                    <tr class="col">
                        <th>Nome</th>
                        <th>Editar</th>
                        <th>Excluir</th>
                    </tr>
                    <?php $__currentLoopData = $autores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $autores): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($autores->nome); ?></td>
                        <td><a href='/autores/cadastro/<?php echo e($autores->id); ?>'>Editar</a></td>
                        <td><a href='/autores/remover/<?php echo e($autores->id); ?>'>Remover</a></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </table>
            </div>
        </section>
    </main>

    <br><br>
    <div style="text-align: right">
        <a href="/autores/cadastro" class="btn btn-lg btn-primary">Cadastrar Autor</a>
    </div>

    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-10.x\resources\views/autores/index.blade.php ENDPATH**/ ?>