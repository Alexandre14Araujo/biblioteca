<?php $__env->startSection('title', 'Biblioteca'); ?>

<?php $__env->startSection('h1', 'Lista de emprestimos'); ?>

<?php $__env->startSection('content'); ?>

<main class="py-5">
       <section class="py-5">
            <div class="container">
                <table class="table">
                <tr class="col">
                <th>Nome</th>
                <th>Livro</th>
                <th>Editar</th>
                <th>Excluir</th>
                </tr>
                <?php $__currentLoopData = $emprestimos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $emprestimo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                <td><?php echo e(isset($emprestimo->usuario) ? $emprestimo->usuario->nome : 'Sem usuario'); ?></td>
                <td><?php echo e(isset($emprestimo->livro) ? $emprestimo->livro->titulo : 'Sem Livro'); ?></td>
                <td><a href='/emprestimos/cadastro/<?php echo e($emprestimo->id); ?>'>Editar</a></td>
                <td><a href='/emprestimos/remover/<?php echo e($emprestimo->id); ?>'>Remover</a></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </table>
            </div>
        </section>
</main>

                <br><br>
<div style="text-align: right;">

    <a href="/emprestimos/cadastro" class="btn btn-lg btn-primary" >Cadastrar emprestimo</a>
</div>




<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-10.x\resources\views/emprestimos/index.blade.php ENDPATH**/ ?>