Página de Produtos
<br><br>

<table border="1">
    <tr>
        <td>Nome</td>
        <td>Quantidade</td>
    </tr>
    <?php $__currentLoopData = $produtos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $valor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><?php echo e($valor->nome); ?></td>
        <td><?php echo e($valor->quantidade); ?></td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</able>
<?php /**PATH C:\xampp\htdocs\laravel-10.x\resources\views/produtos.blade.php ENDPATH**/ ?>