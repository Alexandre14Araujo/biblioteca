<?php $__env->startSection('title', 'Cadastrar Livro'); ?>

<?php $__env->startSection('h1', 'Cadastro de Livro'); ?>

<?php $__env->startSection('content'); ?>

    <main class="py-5">
        <section class="py-5">
            <div class="container">
                <form method="POST" action="/autores/salvar">
                    <?php echo csrf_field(); ?>
                    <div class="form-row">
                        <div class="form-group">
                            <label for="nome" class="form-label">Nome</label>
                            <input type="text" name="nome" placeholder="Digite o seu Nome" class="form-control"
                                value="<?php echo e(@$resultado->nome); ?>"><br><br>
                        </div>
                        <div class="form-group">
                            <input type="hidden" name="id" value="<?php echo e(@$resultado->id); ?>">
                        </div>
                        <button type="submit" class="btn btn-primary">Salvar</button>
                    </div>
                </form>
            </div>
        </section>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-10.x\resources\views/autores/cadastro.blade.php ENDPATH**/ ?>