<?php $__env->startSection('title', 'Biblioteca'); ?>

<?php $__env->startSection('h1', 'Lista de livros'); ?>

<?php $__env->startSection('content'); ?>

<main class="py-5">
       <section class="py-5">
            <div class="container">
                <table class="table">
                <tr class="col">
                <th>Título</th>
                <th>Autor</th>
                <th>Editar</th>
                <th>Excluir</th>
                </tr>
                <?php $__currentLoopData = $livros; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $livro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                <td><?php echo e($livro->titulo); ?></td>
                <td><?php echo e(isset($livro->autor) ? $livro->autor->nome : 'Sem autor'); ?></td>
                <td><a href='/livros/cadastro/<?php echo e($livro->id); ?>'>Editar</a></td>
                <td><a href='/livros/remover/<?php echo e($livro->id); ?>'>Remover</a></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </table>
            </div>
        </section>
</main>

                <br><br>
<div style="text-align: right;">

    <a href="/livros/cadastro" class="btn btn-lg btn-primary" >Cadastrar livro</a>
</div>




<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-10.x\resources\views/livros/index.blade.php ENDPATH**/ ?>