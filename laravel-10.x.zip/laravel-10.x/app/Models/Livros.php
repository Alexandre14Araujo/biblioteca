<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use App\Models\autores;
use Illuminate\Database\Eloquent\Relations\HasOne;

class Livros extends Model
{
    protected $table = 'livros';

    public function autores(){
        return $this->HasOne(autores::class, 'id', 'id_autores');
    }

}
?>