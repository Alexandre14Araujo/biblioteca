<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Emprestimos extends Model
{
    public function usuarios()
    {
        return $this->hasOne(usuarios::class, 'id', 'id_usuarios');
    }

    public function livros(){
        return $this->hasOne(livros::class, 'id', 'id_livros');
    }
}
?>
