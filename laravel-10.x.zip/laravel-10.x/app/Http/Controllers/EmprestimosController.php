<?php
namespace App\Http\Controllers;

use App\Models\Usuarios;
use App\Models\Livros;
use Illuminate\Http\Request;
use App\Models\Emprestimos;

class EmprestimosController extends Controller
{
    public function index()
    {
        $emprestimos = Emprestimos::get();
        return view('emprestimos.index',compact('emprestimos'));
    }

    public function cadastro($id=null)
    {
        $resultado = null;
        if($id){
            $resultado = Emprestimos::find($id);
        }
        $livros = Livros::get();
        $usuarios = Usuarios::get();
            return view('emprestimos.cadastro', compact('resultado','usuarios','livros'));
    }

    public function salvar(Request $request)
    {
        if($request->id){
            $r = Emprestimos::find($request->id);
        }else{
            $r = new Emprestimos;
        }

        $r->data_emprestimos = $request->data_emprestimos;
        $r->data_devolucao = $request->data_devolucao;
        $r->id_livros = $request->id_livro;
        $r->id_usuarios = $request->id_usuario;


    $r->save();
    return redirect('/emprestimos');
}

    public function remover($id){
        $r = Emprestimos::find($id);
        $r->delete();

        return redirect('/emprestimos');
    }

}
