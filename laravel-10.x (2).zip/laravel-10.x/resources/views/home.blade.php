@extends('layouts.main')

@section('title', 'Biblioteca')

@section('h1', 'Bem-vindo a nossa biblioteca')

@section('content')

@endsection
