@extends('layouts.main')

@section('title', 'Biblioteca')

@section('h1', 'Lista de emprestimos')

@section('content')

<main class="py-5">
       <section class="py-5">
            <div class="container">
                <table class="table">
                <tr class="col">
                <th>Nome</th>
                <th>Livro</th>
                <th>Editar</th>
                <th>Excluir</th>
                </tr>
                @foreach($emprestimos as $emprestimo)
                <tr>
                <td>{{ isset($emprestimo->usuario) ? $emprestimo->usuario->nome : 'Sem usuario' }}</td>
                <td>{{ isset($emprestimo->livro) ? $emprestimo->livro->titulo : 'Sem Livro' }}</td>
                <td><a href='/emprestimos/cadastro/{{ $emprestimo->id }}'>Editar</a></td>
                <td><a href='/emprestimos/remover/{{ $emprestimo->id }}'>Remover</a></td>
                </tr>
                @endforeach
                </table>
            </div>
        </section>
</main>

                <br><br>
<div style="text-align: right;">

    <a href="/emprestimos/cadastro" class="btn btn-lg btn-primary" >Cadastrar emprestimo</a>
</div>




@endsection
