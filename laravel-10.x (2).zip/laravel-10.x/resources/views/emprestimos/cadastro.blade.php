@extends('layouts.main')

@section('title', 'Cadastrar Livro')

@section('h1', 'Cadastro de livro')

@section('content')

   <main class="py-5">
       <section class="py-5">
            <div class="container">
                    <form method="POST" action="/emprestimos/salvar">
                        @csrf
                        <div class="form-row">
                            <div class="form-group">
                                <label for="nome" class="form-label">Nome</label> <br>
                                <select name="id_usuario">
                                <option value="">Selecione um nome</option>
                                @foreach($usuarios as $usuario)
                                <option value="{{$usuario->id}}">{{$usuario->nome}}</option>
                                @endforeach
                                </select>
                            </div>
                            <br><br>
                            <div class="form-group">
                                <label for="livro" class="form-label">Livro</label> <br>
                                <select name="id_livro">
                                <option value="">Selecione um livro</option>
                                @foreach($livros as $livro)
                                <option value="{{$livro->id}}">{{$livro->titulo}}</option>
                                @endforeach
                                </select>
                            </div>
                            <br><br>
                            <div class="form-group">
                                <label for="dataEmprestimo" class="form-label">Data do empréstimo </label>
                                <input type="date" name="data_emprestimo"  class="form-control" value="{{@$resultado->data_emprestimo}}"><br>
                            </div>
                            <div class="form-group">
                                <label for="dataDevolucao" class="form-label">Data da devolução </label>
                                <input type="date" name="data_devolucao" class="form-control" value="{{@$resultado->data_devolucao}}"><br>
                            </div>

                            <div>

                                <input type="hidden" name="id" value="{{@$resultado->id}}">
                            </div>
                            <button type="submit" class="btn btn-primary">Salvar</button>
                        </div>
                    </form>
            </div>

       </section>
   </main>

@endsection
