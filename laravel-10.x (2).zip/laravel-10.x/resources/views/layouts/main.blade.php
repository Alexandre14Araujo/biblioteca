<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title> @yield('title')</title>

        <!-- Fonts Google -->
        <link href="https://fonts.googleapis.com/css2?family=Roboto" rel="stylesheet">

        <!-- Css Bootstrap -->
        <link
            href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css"
            rel="stylesheet"
            integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN"
            crossorigin="anonymous"

        />
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">

         <!-- Css da aplicação -->
         <link rel="stylesheet" href="/assets/css/style.css">
         <script src="/resources/js/app.js"></script>

        <!-- Fonts -->
        <link rel="preconnect" href="https://fonts.bunny.net">
        <link href="https://fonts.bunny.net/css?family=figtree:400,600&display=swap" rel="stylesheet" />

        </head>
        <body>
                <nav class="navbar navbar-expand-lg navbar-light">
                    <div class="collapse navbar-collapse" id="navbar">
                        
                        <ul class="navbar-nav">
                            <li class="nav-item">
                                <a href="/usuarios" class="nav-link">Usuário</a>
                            </li>
                            <li class="nav-item">
                                <a href="/autores" class="nav-link">Autor</a>
                            </li>
                            <li class="nav-item">
                                <a href="/livros" class="nav-link">Livros</a>
                            </li>
                            <li class="nav-item">
                                <a href="/emprestimos" class="nav-link">Emprestimos</a>
                            </li>
                        </ul>
                    </div>
                </nav>
                <header class="bg-primary text-white text-center py-5">
                <div class="container">
                    <h1> @yield('h1')</h1>
                    <p class="lead"> Cadastre-se e receba as notícias em tempo real </p>
                    <a href="/usuarios/cadastro/'" class="btn btn-lg btn-light"> Saiba mais...</a>
                </div>
    </header>


    <!--Rodape -->

    @yield('content')
    <br>
    <footer class="bg-info text-black text-center py-4">
            <div class="container">
                <p> &copy; 2024 Landpage - Todos os Direitos Reservados a Alexandre Augusto</p>
            </div>
            <div class="social-icons mt-3">
                <a href="#" class="text-black me-3"><i class="bi bi-instagram"></i></a>
                <a href="#" class="text-black me-3"><i class="bi bi-facebook"></i></a>
                <a href="#" class="text-black me-3"><i class="bi bi-linkedin"></i></a>
                <a href="#" class="text-black me-3"><i class="bi bi-whatsapp"></i></a>
            </div>
        </footer>

        <!-- Bootstrap JavaScript Libraries -->
        <script
            src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js"
            integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r"
            crossorigin="anonymous"
        ></script>

        <script
            src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.min.js"
            integrity="sha384-BBtl+eGJRgqQAUMxJ7pMwbEyER4l1g+O15P+16Ep7Q9Q+zqX6gSbd85u4mG4QzX+"
            crossorigin="anonymous"
        ></script>

    </body>
</html>
