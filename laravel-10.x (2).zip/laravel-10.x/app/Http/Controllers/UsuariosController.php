<?php
namespace App\Http\Controllers;

use App\Models\Usuarios;
use Illuminate\Http\Request;

class UsuariosController extends Controller
{
    public function index()
    {
        $usuarios = Usuarios::all();
        return view('usuarios.index',compact('usuarios'));
    }

    public function cadastro(Request $request)
    {
        $resultado = null;
        if($request->id){
            $resultado = Usuarios::find( $request->id );
        }

        return view('usuarios.cadastro',compact('resultado'));
    }

    public function salvar(Request $request)
    {
        if($request->id){
            $u = Usuarios::find($request->id);
        }else{
            $u = new Usuarios;
        }

        $u->nome = $request->nome;
        $u->email = $request->email;
        if($request->senha){
            $u->senha = ($request->senha);
        }
        $u->save();

        return redirect('/usuarios');
    }

    public function remover($id)
    {
       $u = Usuarios::find($id);
       $u->delete();

       return redirect('/usuarios');
    }
}
?>