<?php $__env->startSection('title', 'Criar Usuários'); ?>

<?php $__env->startSection('h1', 'Cadastro de usuário'); ?>

<?php $__env->startSection('content'); ?>

   <main class="py-5">
       <section class="py-5">
            <div class="container">
                    <form method="POST" action="/usuarios/salvar">
                        <?php echo csrf_field(); ?>
                        <div class="form-row">
                            <div class="form-group">
                                <label for="nome" class="form-label">Nome </label>
                                <input type="text" name="nome" placeholder="Digite seu nome" class="form-control" value="<?php echo e(@$resultado->nome); ?>"><br>
                            </div>
                            <div class="form-group">
                                <label for="email" >Email</label>
                                <input type="email" name="email" placeholder="Digite seu email" class="form-control" value="<?php echo e(@$resultado->email); ?>">
                                <small id="emailHelp">Dados de email seguros! Não compartilhado!</small><br><br>
                            </div>
                            <div class="form-group">
                                <label for="senha" class="form-label">Senha:</label>
                                <input type="password" name="senha"  placeholder="Digite sua senha" class="form-control"><br>
                            </div>
                            <div class="form-group col-md-3">

                                <input type="hidden" name="id" value="<?php echo e(@$resultado->id); ?>">
                            </div>
                            <button type="submit" class="btn btn-primary">Salvar</button>
                        </div>
                    </form>
            </div>

       </section>
   </main>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-10.x\resources\views/usuarios/cadastro.blade.php ENDPATH**/ ?>