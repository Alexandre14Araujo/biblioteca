<?php $__env->startSection('title', 'Biblioteca'); ?>

<?php $__env->startSection('h1', 'Bem-vindo a nossa biblioteca'); ?>

<?php $__env->startSection('content'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-10.x\resources\views/home.blade.php ENDPATH**/ ?>