<?php $__env->startSection('title', 'Cadastrar Livro'); ?>

<?php $__env->startSection('h1', 'Cadastro de livro'); ?>

<?php $__env->startSection('content'); ?>

   <main class="py-5">
       <section class="py-5">
            <div class="container">
                    <form method="POST" action="/emprestimos/salvar">
                        <?php echo csrf_field(); ?>
                        <div class="form-row">
                            <div class="form-group">
                                <label for="nome" class="form-label">Nome</label> <br>
                                <select name="id_usuario">
                                <option value="">Selecione um nome</option>
                                <?php $__currentLoopData = $usuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usuario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($usuario->id); ?>"><?php echo e($usuario->nome); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <br><br>
                            <div class="form-group">
                                <label for="livro" class="form-label">Livro</label> <br>
                                <select name="id_livro">
                                <option value="">Selecione um livro</option>
                                <?php $__currentLoopData = $livros; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $livro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($livro->id); ?>"><?php echo e($livro->titulo); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <br><br>
                            <div class="form-group">
                                <label for="dataEmprestimo" class="form-label">Data do empréstimo </label>
                                <input type="date" name="data_emprestimo"  class="form-control" value="<?php echo e(@$resultado->data_emprestimo); ?>"><br>
                            </div>
                            <div class="form-group">
                                <label for="dataDevolucao" class="form-label">Data da devolução </label>
                                <input type="date" name="data_devolucao" class="form-control" value="<?php echo e(@$resultado->data_devolucao); ?>"><br>
                            </div>

                            <div>

                                <input type="hidden" name="id" value="<?php echo e(@$resultado->id); ?>">
                            </div>
                            <button type="submit" class="btn btn-primary">Salvar</button>
                        </div>
                    </form>
            </div>

       </section>
   </main>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-10.x\resources\views/emprestimos/cadastro.blade.php ENDPATH**/ ?>