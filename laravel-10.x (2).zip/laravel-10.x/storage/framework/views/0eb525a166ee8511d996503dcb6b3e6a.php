Olá, nos somos do Senai
<?php /**PATH C:\xampp\htdocs\laravel-10.x\resources\views/quem_somos.blade.php ENDPATH**/ ?>